package example;

public class HelloWorld {
    public String hello() {
        return "Hello World";
    }
}
